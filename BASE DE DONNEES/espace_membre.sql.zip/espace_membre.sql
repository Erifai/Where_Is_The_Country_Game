-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : jeu. 11 juin 2020 à 01:52
-- Version du serveur :  10.4.11-MariaDB
-- Version de PHP : 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `espace_membre`
--

-- --------------------------------------------------------

--
-- Structure de la table `membres`
--

CREATE TABLE `membres` (
  `id` int(11) NOT NULL,
  `pseudo` varchar(25) NOT NULL,
  `mail` varchar(25) NOT NULL,
  `motdepasse` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `membres`
--

INSERT INTO `membres` (`id`, `pseudo`, `mail`, `motdepasse`) VALUES
(32, 'admin', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997'),
(33, 'gmmaamir', 'gm_maamir@esi.dz', '9cf95dacd226dcf43da376cdb6cbba7035218921'),
(34, 'fatima', 'fatima@gmail.com', '1ba1b5b562aef9cd264cace5b7bdd46a7c065c0a'),
(35, 'Djahida', 'Djahida_ben@gmail.com', '506ab191b1ef26354d5a5ac6348196ee71afdda2');

-- --------------------------------------------------------

--
-- Structure de la table `mespays`
--

CREATE TABLE `mespays` (
  `id_pays` int(11) NOT NULL,
  `Nom_pays` varchar(255) NOT NULL,
  `Nom_continent` text NOT NULL,
  `Flag` mediumtext NOT NULL,
  `Reference` mediumtext NOT NULL,
  `Surface` float NOT NULL,
  `Langue` varchar(255) NOT NULL,
  `Lien` mediumtext NOT NULL,
  `Img` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `mespays`
--

INSERT INTO `mespays` (`id_pays`, `Nom_pays`, `Nom_continent`, `Flag`, `Reference`, `Surface`, `Langue`, `Lien`, `Img`) VALUES
(10, 'Aruba', 'Amerique', '../../data/abw.svg', '../../data/abw.geo.json', 180, 'Neerlandais', 'https://fr.wikipedia.org/wiki/Aruba', 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e2/Aruba_landbridge.jpg/800px-Aruba_landbridge.jpg'),
(11, 'Anguilla', 'Amerique', '../../data/aia.svg', '../../data/aia.geo.json', 91, 'Anglais', 'https://fr.wikipedia.org/wiki/Anguilla', 'https://www.planetware.com/photos-large/ANL/anguilla-shoal-bay-beach.jpg'),
(12, 'Argentine', 'Amerique', '../../data/arg.svg', '../../data/arg.geo.json', 2780000, 'Espagnol', 'https://fr.wikipedia.org/wiki/Argentine', 'https://www.planetware.com/photos-large/ARG/argentina-top-attractions-iguazu-falls.jpg'),
(13, 'Samoa americaines', 'Amerique', '../../data/asm.svg', '../../data/asm.geo.json', 199, 'samoan', 'https://fr.wikipedia.org/wiki/Samoa_am%C3%A9ricaines', 'https://www.visittheusa.fr/sites/default/files/styles/hero_m_1300x700/public/images/hero_media_image/2018-04/117c3c2d2b74011e064afd38bdb2ae9a.jpeg'),
(14, 'Antigua et Barbuda', 'Amerique', '../../data/atg.svg', '../../data/atg.geo.json', 440, 'Anglais', 'https://fr.wikipedia.org/wiki/Terres_australes_et_antarctiques_fran%C3%A7aises', 'https://media.privileges-voyages.com/resizer/r/1600-900-1-100/medias/mediatheque/produits/NWL103/Jumby-Bay-Antigua-et-Barbuda-piscine-mer.jpg'),
(15, 'Saba Saint Eustache et Bonaire', 'Amerique', '../../data/bes.svg', '../../data/bes.geo.json', 328, 'papiamento', 'https://fr.wikipedia.org/wiki/Bonaire', 'https://a.travel-assets.com/findyours-php/viewfinder/images/res30/197000/197005-Bonaire.jpg'),
(16, 'Bahamas', 'Amerique', '../../data/bhs.svg', '../../data/bhs.geo.json', 13878, 'Anglais', 'https://fr.wikipedia.org/wiki/Bahamas', 'https://www.traveltradecaribbean.com/wp-content/uploads/2013/06/bahamas-sex-tourism.jpg'),
(17, 'Saint  Barthelemy', 'Amerique', '../../data/blm.svg', '../../data/blm.geo.json', 24, 'Francais', 'https://fr.wikipedia.org/wiki/Saint_Barth%C3%A9lemy', 'https://cdn.kactus.com/pictures/000/162/020/large/comptoir_de_degustation_le_st_barth_au_bord_de_la_lagune_vos_evements_au_st_barth.jpg'),
(18, 'Belize', 'Amerique', '../../data/blz.svg', '../../data/blz.geo.json', 22965, 'Anglais', 'https://fr.wikipedia.org/wiki/Belize', 'https://www.touropia.com/gfx/d/tourist-attractions-in-belize/xunantunich.jpg'),
(19, 'Bolivie', 'Amerique', '../../data/bol.svg', '../../data/bol.geo.json', 1099000, 'espagnol', 'https://fr.wikipedia.org/wiki/Bolivie', 'https://www.tourismesolidaire.org/medias/travels/terres-andes-bolivie-combine-chez-nos-amis-perou-bolivie__20151125175719.jpg'),
(20, 'Bresil', 'Amerique', '../../data/bra.svg', '../../data/bra.geo.json', 8516000, 'Portugais', 'https://fr.wikipedia.org/wiki/Br%C3%A9sil', 'https://www.tourisme-bresil.com/wp-content/uploads/voyage-bresil-agence-terra-brazil-1280x800.jpg'),
(21, 'Barbados', 'Amerique', '../../data/brb.svg', '../../data/brb.geo.json', 431, 'Anglais', 'https://fr.wikipedia.org/wiki/Barbade', 'https://umaizi.com/wp-content/uploads/2016/09/Barbados-Tourism-Sector.jpg'),
(22, 'Canada', 'Amerique', '../../data/can.svg', '../../data/can.geo.json', 9985000, 'francais', 'https://fr.wikipedia.org/wiki/Canada', 'https://www.rcinet.ca/en/wp-content/uploads/sites/3/2018/11/istock-855077630-635x357.jpg'),
(23, 'Chili', 'Amerique', '../../data/chl.svg', '../../data/chl.geo.json', 756950, 'Espagnol', 'https://fr.wikipedia.org/wiki/Chili', 'https://www.ville-courbevoie.fr/fileadmin/_processed_/6/f/csm_noel-chili_3236d29fe7.jpg'),
(24, 'Colombie', 'Amerique', '../../data/col.svg', '../../data/col.geo.json', 1142000, 'Espagnol', 'https://fr.wikipedia.org/wiki/Colombie', 'https://cdn.cnn.com/cnnnext/dam/assets/190820104325-01-things-to-do-cartagena-colombia.jpg'),
(25, 'Costa Rica', 'Amerique', '../../data/cri.svg', '../../data/cri.geo.json', 51100, 'Espagnol', 'https://fr.wikipedia.org/wiki/Costa_Rica', 'https://www.kcsanjose.com/blog/core/_media/2017/05/cr12.jpg'),
(26, 'Cuba', 'Amerique', '../../data/cub.svg', '../../data/cub.geo.json', 109884, 'Espagnol', 'https://fr.wikipedia.org/wiki/Cuba', 'https://i2.wp.com/ips-dc.org/wp-content/uploads/2019/06/cuba.jpg'),
(27, 'Curacao', 'Amerique', '../../data/cuw.svg', '../../data/cuw.geo.json', 444, 'neerlandais', 'https://fr.wikipedia.org/wiki/Cura%C3%A7ao', 'https://www.travelweek.ca/wp-content/uploads/2018/07/North-American-arrivals-help-spur-tourism-growth-in-Curac%CC%A7ao.jpg'),
(28, 'Iles Caimans', 'Amerique', '../../data/cym.svg', '../../data/cym.geo.json', 259, 'Anglais', 'https://fr.wikipedia.org/wiki/%C3%8Eles_Ca%C3%AFmans', 'https://www.bouger-voyager.com/wp-content/uploads/2017/09/seven-mile-beach-grand-cayman-3.jpg'),
(29, 'Dominique', 'Amerique', '../../data/dma.svg', '../../data/dma.geo.json', 750, 'Anglais', 'https://fr.wikipedia.org/wiki/Dominique', 'https://www.rainforestecoresort.com/img/cbi-photo-1.jpg'),
(30, 'Republique Dominicaine', 'Amerique', '../../data/dom.svg', '../../data/dom.geo.json', 48442, 'Espagnol', 'https://fr.wikipedia.org/wiki/R%C3%A9publique_dominicaine', 'https://www.godominicanrepublic.com/wp-content/uploads/2019/05/republique-dominicaine-24-000-nouvelles-chambres-a-la-fin-2019.jpg'),
(31, 'Equateur', 'Amerique', '../../data/ecu.svg', '../../data/ecu.geo.json', 283560, 'Espagnol', 'https://fr.wikipedia.org/wiki/%C3%89quateur', 'https://espaces-andins.com/wp-content/uploads/2015/04/SLIDE-3-marche-de-Cuenca-1.jpeg'),
(32, 'Iles Falkland', 'Amerique', '../../data/flk.svg', '../../data/flk.geo.json', 12173, 'Anglais', 'https://fr.wikipedia.org/wiki/%C3%8Eles_Malouines', 'https://www.soscroisiere.com/back/images/escales/petit/small_jpg-20181025105442102.jpg'),
(33, 'Guadeloupe', 'Amerique', '../../data/glp.svg', '../../data/glp.geo.json', 1628, 'Francais', 'https://fr.wikipedia.org/wiki/Guadeloupe', 'https://meetandtravelmag.com/IMG/jpg/Plage-en-Guadeloupe.jpg'),
(34, 'Grenade', 'Amerique', '../../data/grd.svg', '../../data/grd.geo.json', 348.5, 'Anglais', 'https://fr.wikipedia.org/wiki/Grenade', 'https://voyages.michelin.fr/sites/default/files/styles/poi_slideshow_big/public/images/travel_guide/NX-22684.jpg'),
(35, 'Groenland', 'Amerique', '../../data/grl.svg', '../../data/grl.geo.json', 2166000, 'Groenlandais', 'https://fr.wikipedia.org/wiki/Groenland', 'https://www.tirawa.com/medias/cache/trip_detail_fancy/medias/voyages/europe/groenland/5d75f6e51379e-groenland.jpeg'),
(36, 'Guatemala', 'Amerique', '../../data/gtm.svg', '../../data/gtm.geo.json', 108888, 'Espagnol', 'https://fr.wikipedia.org/wiki/Guatemala', 'https://www.planetware.com/photos-large/GUA/guatemala-tikal-ruins.jpg'),
(37, 'Guyane francaise', 'Amerique', '../../data/guf.svg', '../../data/guf.geo.json', 83534, 'francais', 'https://fr.wikipedia.org/wiki/Guyane', 'https://media-cdn.tripadvisor.com/media/photo-s/14/cc/ac/90/dsc-1685-largejpg.jpg'),
(38, 'Guam', 'Amerique', '../../data/gum.svg', '../../data/gum.geo.json', 549, 'anglais', 'https://fr.wikipedia.org/wiki/Guam', 'https://cdn.travelpulse.com/images/99999999-9999-9999-9999-999999999999/dcc809d2-8197-e511-8b9f-0050568e420d/630x355.jpg'),
(39, 'Guyane', 'Amerique', '../../data/guy.svg', '../../data/guy.geo.json', 214969, 'francais ', 'https://fr.wikipedia.org/wiki/Guyane', 'https://cap.img.pmdstatic.net/fit/http.3A.2F.2Fprd2-bone-image.2Es3-website-eu-west-1.2Eamazonaws.2Ecom.2FAFP.2F2018.2F07.2F14.2F29a5b911-09cd-4279-ab50-befb7cd0aac5.2Ejpeg/750x375/background-color/ffffff/quality/70/une-campagne-2-0-pour-faire-de-la-guyane-une-destination-touristique-1298046.jpg'),
(40, 'Honduras', 'Amerique', '../../data/hnd.svg', '../../data/hnd.geo.json', 112492, 'Espagnol', 'https://fr.wikipedia.org/wiki/Honduras', 'https://cdn.travelpulse.com/images/99999999-9999-9999-9999-999999999999/82173be7-ef84-c534-467a-35aa869cfa79/630x355.jpg'),
(41, 'Haiti', 'Amerique', '../../data/hti.svg', '../../data/hti.geo.json', 27750, 'creole haitien', 'https://fr.wikipedia.org/wiki/Ha%C3%AFti', 'https://www.eturbonews.com/wp-content/uploads/2017/03/unwto%20haiti.png'),
(42, 'Jamaique', 'Amerique', '../../data/jam.svg', '../../data/jam.geo.json', 10992, 'Anglais', 'https://fr.wikipedia.org/wiki/Jama%C3%AFque', 'https://www.lonelyplanet.fr/sites/lonelyplanet/files/styles/manual_crop/public/media/destination/slider/mobile/500px_53801338_0.jpg'),
(43, 'Saint Kitts et Nevis', 'Amerique', '../../data/kna.svg', '../../data/kna.geo.json', 269.4, 'Anglais', 'https://fr.wikipedia.org/wiki/Saint-Christophe-et-Ni%C3%A9v%C3%A8s', 'https://www.caribbeanislands.com/fr/i/saint-christophe-et-nieves/saint-christophe-et-nieves.jpg'),
(44, 'Sainte Lucie', 'Amerique', '../../data/lca.svg', '../../data/lca.geo.json', 617, 'Anglais', 'https://fr.wikipedia.org/wiki/Sainte-Lucie', 'https://www.infotravel.fr//wp-content/uploads/2012/06/li%CC%82le-de-Sainte-Lucie_Infotravel-.jpg'),
(45, 'Saint Martin', 'Amerique', '../../data/maf.svg', '../../data/maf.geo.json', 87, 'Francais', 'https://fr.wikipedia.org/wiki/Saint-Martin', 'https://saint-martin.com/wp-content/uploads/2020/03/antigua--1024x576.jpg'),
(46, 'Mexique', 'Amerique', '../../data/mex.svg', '../../data/mex.geo.json', 1973000, 'espagnol', 'https://fr.wikipedia.org/wiki/Mexique', 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ae/Cancun_aerial_photo_by_safa.jpg/1200px-Cancun_aerial_photo_by_safa.jpg'),
(47, 'Montserrat', 'Amerique', '../../data/msr.svg', '../../data/msr.geo.json', 102, 'Anglais', 'https://fr.wikipedia.org/wiki/Montserrat_(Antilles)', 'https://media.tacdn.com/media/attractions-splice-spp-674x446/06/ed/82/51.jpg'),
(48, 'Martinique', 'Amerique', '../../data/mtq.svg', '../../data/mtq.geo.json', 1128, 'Francais', 'https://fr.wikipedia.org/wiki/Martinique', 'https://www.travelvivi.com/wp-content/uploads/2013/04/Martinique-Island.jpg'),
(49, 'Nicaragua', 'Amerique', '../../data/nic.svg', '../../data/nic.geo.json', 923768, 'Espagnol', 'https://fr.wikipedia.org/wiki/Nicaragua', 'https://i.pinimg.com/originals/2f/cf/91/2fcf917a9c2e634a606ec572834221f1.jpg'),
(50, 'Perou', 'Amerique', '../../data/per.svg', '../../data/per.geo.json', 1285000, 'espagnol', 'https://fr.wikipedia.org/wiki/P%C3%A9rou', 'https://cdn.generationvoyage.fr/2013/05/Cost-of-living-Peru.jpg'),
(51, 'Puerto Rico', 'Amerique', '../../data/pri.svg', '../../data/pri.geo.json', 13800, ' espagnol', 'https://fr.wikipedia.org/wiki/Porto_Rico', 'https://qtxasset.com/travelagentcentral/1565889589/shutterstock_1067855027.jpg'),
(52, 'Paraguay', 'Amerique', '../../data/pry.svg', '../../data/pry.geo.json', 406752, 'guarani', 'https://fr.wikipedia.org/wiki/Paraguay', 'https://itap-world.com/uploads/countries/1/1447/1274.jpg'),
(53, 'Le Salvador', 'Amerique', '../../data/slv.svg', '../../data/slv.geo.json', 21041, 'Espagnol', 'https://fr.wikipedia.org/wiki/Salvador', 'https://cdn.travelpulse.com/images/21aaedf4-a957-df11-b491-006073e71405/0b1c3203-e827-410b-b861-2509bf8e859e/630x355.jpg'),
(54, 'Saint Pierre et Miquelon', 'Amerique', '../../data/spm.svg', '../../data/spm.geo.json', 242, 'Francais', 'https://fr.wikipedia.org/wiki/Saint-Pierre-et-Miquelon', 'https://borgenproject.org/wp-content/uploads/7211151830_0e3d2d5007_z.jpg'),
(55, 'Surinam', 'Amerique', '../../data/sur.svg', '../../data/sur.geo.json', 163821, 'Neerlandais', 'https://fr.wikipedia.org/wiki/Suriname', 'https://i1.wp.com/lapetiteboussole.com/wp-content/uploads/2018/08/SURINAME-1.jpg'),
(56, 'Saint Martin', 'Amerique', '../../data/sxm.svg', '../../data/sxm.geo.json', 87, 'Francais', 'https://fr.wikipedia.org/wiki/Saint-Martin_(%C3%AEle)', 'https://france-amerique.com/wp-content/uploads/2018/10/Screen-Shot-2018-10-11-at-10.28.33-AM-e1539277132933.png'),
(57, 'Iles Turques et Caiques', 'Amerique', '../../data/tca.svg', '../../data/tca.geo.json', 417, 'Anglais', 'https://fr.wikipedia.org/wiki/%C3%8Eles_Turques-et-Ca%C3%AFques', 'https://img.ev.mu/images/portfolio/pays/210/600x400/846577.jpg'),
(58, 'Trinite et Tobago', 'Amerique', '../../data/tto.svg', '../../data/tto.geo.json', 5131, 'Anglais', 'https://fr.wikipedia.org/wiki/Trinit%C3%A9-et-Tobago', 'https://www.newsweed.fr/wp-content/uploads/2019/11/trinite-tobago-legalisation-cannabis.jpg'),
(59, 'Iles Mineures eloignees des Etats Unis', 'Amerique', '../../data/umi.svg', '../../data/umi.geo.json', 34.2, 'Anglais', 'https://fr.wikipedia.org/wiki/%C3%8Eles_mineures_%C3%A9loign%C3%A9es_des_%C3%89tats-Unis', 'https://back-visiteurope.orchestra-platform.com/admin/TS/fckUserFiles/Image/Voyages/Croatie/HRC-GRTC/programme/circuit-croatie-grand-tour-croatie-iles-elaphites-jour-6.jpg'),
(60, 'Uruguay', 'Amerique', '../../data/ury.svg', '../../data/ury.geo.json', 176215, 'Espagnol', 'https://fr.wikipedia.org/wiki/Uruguay', 'https://thebesttravelplaces.com/wp-content/uploads/2016/10/tourist-attractions-Uruguay-1068x710.jpg'),
(61, 'Etats Unis', 'Amerique', '../../data/usa.svg', '../../data/usa.geo.json', 9834000, 'anglais', 'https://fr.wikipedia.org/wiki/%C3%89tats-Unis', 'https://www.eturbonews.com/wp-content/uploads/2019/05/0a1a-323.jpg'),
(62, 'Saint Vincent et les Grenadines', 'Amerique', '../../data/vct.svg', '../../data/vct.geo.json', 389, 'Anglais', 'https://fr.wikipedia.org/wiki/Saint-Vincent-et-les-Grenadines', 'https://i.pinimg.com/originals/e4/20/ae/e420ae21aca20bffcf6b8789861bf28f.jpg'),
(63, 'Venezuela', 'Amerique', '../../data/ven.svg', '../../data/ven.geo.json', 916445, 'Espagnol', 'https://fr.wikipedia.org/wiki/Venezuela', 'https://d.ibtimes.co.uk/en/full/1442644/venezuela-tourism.jpg'),
(64, 'Iles Vierges britanniques', 'Amerique', '../../data/vgb.svg', '../../data/vgb.geo.json', 153, 'Anglais', 'https://fr.wikipedia.org/wiki/%C3%8Eles_Vierges_britanniques', 'https://media-cdn.tripadvisor.com/media/photo-s/0e/0c/24/53/img-20161227-152629-largejpg.jpg'),
(65, 'Iles Vierges des Etats Unis', 'Amerique', '../../data/vir.svg', '../../data/vir.geo.json', 346.4, 'Anglais', 'https://fr.wikipedia.org/wiki/%C3%8Eles_Vierges_des_%C3%89tats-Unis', 'https://www.visittheusa.fr/sites/default/files/styles/hero_m_1300x700/public/images/hero_media_image/2016-09/HERO_stock-photo-st-thomas-97436261_72DPI_0.jpg'),
(66, 'Bermudes', 'Amerique', '../../data/bmu.svg', '../../data/bmu.geo.json', 53.2, 'Anglais', 'https://fr.wikipedia.org/wiki/Bermudes', 'https://cdn.thecrazytourist.com/wp-content/uploads/2018/08/ccimage-shutterstock_653410420.jpg'),
(67, 'Kenya', 'Afrique', '../../data/ken.svg', '../../data/ken.geo.json', 580367, 'swahili', 'https://fr.wikipedia.org/wiki/Kenya', 'https://www.travelwires.com/assets/images/storage/full/lZw0jE5b9PnuDXqrGLoh_full.jpeg'),
(68, 'Liberia', 'Afrique', '../../data/lbr.svg', '../../data/lbr.geo.json', 111369, 'Anglais', 'https://fr.wikipedia.org/wiki/Liberia', 'https://www.iexploreafrica.com/wp-content/uploads/2019/10/Africa-tourism.jpg'),
(69, 'Libye', 'Afrique', '../../data/lby.svg', '../../data/lby.geo.json', 1760000, 'Arabe', 'https://fr.wikipedia.org/wiki/Libye', 'https://medafricatimes.com/wp-content/uploads/2013/07/tourisme-libye.jpg'),
(70, 'Lesotho', 'Afrique', '../../data/lso.svg', '../../data/lso.geo.json', 30355, 'sotho du sud', 'https://fr.wikipedia.org/wiki/Lesotho', 'https://i.pinimg.com/originals/43/63/bc/4363bc8365efa625619d711718dd8215.jpg'),
(71, 'Maroc', 'Afrique', '../../data/mar.svg', '../../data/mar.geo.json', 710850, 'Arabe', 'https://fr.wikipedia.org/wiki/Maroc', 'https://www.lesinfos.ma/static/image_500_285_20200304_512786109.jpg'),
(72, 'Madagascar', 'Afrique', '../../data/mdg.svg', '../../data/mdg.geo.json', 587041, 'malgache', 'https://fr.wikipedia.org/wiki/Madagascar', 'https://i1.wp.com/globalriskinsights.com/wp-content/uploads/2015/05/Nosy-Be-Amazing.jpg'),
(73, 'Mali', 'Afrique', '../../data/mli.svg', '../../data/mli.geo.json', 1240000, 'Francais', 'https://fr.wikipedia.org/wiki/Mali', 'https://i0.wp.com/westafricatourism.com/wp-content/uploads/2016/04/mali1.jpg'),
(74, 'Mauritanie', 'Afrique', '../../data/mrt.svg', '../../data/mrt.geo.json', 1030000, 'Arabe', 'https://fr.wikipedia.org/wiki/Mauritanie', 'https://www.huwans-clubaventure.fr/upload_1000/Mauritanie-0627.jpg'),
(75, 'Ile Maurice', 'Afrique', '../../data/mus.svg', '../../data/mus.geo.json', 2040, 'Anglais', 'https://fr.wikipedia.org/wiki/%C3%8Ele_Maurice', 'https://vacancesmaurice.com/slir/w464/content/images/guide/i-80/mauritius-beaches%20(2).jpg'),
(76, 'Malawi', 'Afrique', '../../data/mwi.svg', '../../data/mwi.geo.json', 118484, 'Anglais', 'https://fr.wikipedia.org/wiki/Malawi', 'https://traveltradedaily.com/media/k2/items/cache/82e69f2bbd1948a1da1f4dfafd94ad3c_XL.jpg'),
(77, 'Mayotte', 'Afrique', '../../data/myt.svg', '../../data/myt.geo.json', 374, 'Francais', 'https://fr.wikipedia.org/wiki/Mayotte', 'https://www.indian-ocean-times.com/photo/art/default/6832237-10440202.jpg'),
(78, 'Namibie', 'Afrique', '../../data/nam.svg', '../../data/nam.geo.json', 825419, 'Anglais', 'https://fr.wikipedia.org/wiki/Namibie', 'https://www.laquotidienne.fr/wp-content/uploads/2019/03/course-1.jpg'),
(79, 'Niger', 'Afrique', '../../data/ner.svg', '../../data/ner.geo.json', 1268000, 'Francais', 'https://fr.wikipedia.org/wiki/Niger', 'https://wathi.org/wp-content/uploads/2019/04/Agadez-600x360.jpg'),
(80, 'Nigeria', 'Afrique', '../../data/nga.svg', '../../data/nga.geo.json', 923768, 'Anglais', 'https://fr.wikipedia.org/wiki/Nigeria', 'https://miro.medium.com/max/4096/1*TXyrsXbRTxhGBeH-jlqMfg.jpeg'),
(81, 'La Reunion', 'Afrique', '../../data/reu.svg', '../../data/reu.geo.json', 2512, 'francais', 'https://fr.wikipedia.org/wiki/La_R%C3%A9union', 'https://www.eturbonews.com/wp-content/uploads/2019/04/reunion.jpg'),
(82, 'Rwanda', 'Afrique', '../../data/rwa.svg', '../../data/rwa.geo.json', 26338, 'kinyarwanda', 'https://fr.wikipedia.org/wiki/Rwanda', 'https://rdb.rw/wp-content/uploads/2019/05/IMG_9449-1024x495.jpg'),
(83, 'Soudan', 'Afrique', '../../data/sdn.svg', '../../data/sdn.geo.json', 1886000, 'Arabe', 'https://fr.wikipedia.org/wiki/Soudan', 'https://d1epq84pwgteub.cloudfront.net/files/0/sites/3/2017/04/shutterstock_149752532-1635x1090.jpg'),
(84, 'Senegal', 'Afrique', '../../data/sen.svg', '../../data/sen.geo.json', 196712, 'Francais', 'https://fr.wikipedia.org/wiki/S%C3%A9n%C3%A9gal', 'https://afrotourism.com/wp-content/uploads/2015/06/LAC-ROSE4-1.jpg'),
(85, 'Sainte Helene', 'Afrique', '../../data/shn.svg', '../../data/shn.geo.json', 121, 'Anglais', 'https://fr.wikipedia.org/wiki/Sainte_H%C3%A9l%C3%A8ne', 'https://static.lexpress.fr/medias_10390/w_1000,h_563,c_fill,g_north/v1428921505/des-passagers-se-prelassent-le-6-mars-2015-sur-le-pont-du-rms-royal-mail-ship-st-helena-sur-le-trajet-entre-le-port-sud-africain-du-cap-et-l-ile-britannique-de-sainte-helene-dans-l-atlantique-sud_5319681.jpg'),
(86, 'Sierra Leone', 'Afrique', '../../data/sle.svg', '../../data/sle.geo.json', 71740, 'Anglais', 'https://fr.wikipedia.org/wiki/Sierra_Leone', 'https://www.telegraph.co.uk/content/dam/Travel/2019/September/sierra-leone-beach.jpg'),
(87, 'Somalie', 'Afrique', '../../data/som.svg', '../../data/som.geo.json', 637655, 'Somali', 'https://fr.wikipedia.org/wiki/Somalie', 'https://upload.wikimedia.org/wikipedia/commons/e/e2/Bosaso.jpg'),
(88, 'Soudan du Sud', 'Afrique', '../../data/ssd.svg', '../../data/ssd.geo.json', 619745, 'Arabe', 'https://fr.wikipedia.org/wiki/Soudan_du_Sud', 'https://i2.wp.com/lapetiteboussole.com/wp-content/uploads/2018/08/SOUDAN-DU-SUD-1.jpg'),
(89, 'Sao Tome et Principe', 'Afrique', '../../data/stp.svg', '../../data/stp.geo.json', 1001, 'Portugais', 'https://fr.wikipedia.org/wiki/Sao_Tom%C3%A9-et-Principe', 'https://geo.img.pmdstatic.net/fit/http.3A.2F.2Fprd2-bone-image.2Es3-website-eu-west-1.2Eamazonaws.2Ecom.2FGEO.2Fvar.2Fgeo.2Fstorage.2Fimages.2Fmedia.2Fimages.2Fplage-de-praia-banana-sur-l-ile-principe-a-sao-tome-et-principe.2F2455229-2-fre-FR.2Fplage-de-praia-banana-sur-l-ile-principe-a-sao-tome-et-principe.2Ejpg/1120x630/background-color/ffffff/quality/90/sao-tome-et-principe-un-archipel-vierge-au-large-de-l-afrique.jpg'),
(90, 'Swaziland', 'Afrique', '../../data/swz.svg', '../../data/swz.geo.json', 17364, 'swati', 'https://fr.wikipedia.org/wiki/Eswatini', 'https://indietravelpodcast.com/wp-content/uploads/2016/11/Unique-art-and-sculptures-House-On-Fire-Swaziland-Acacia-Africa-750x563.jpg'),
(91, 'Seychelles', 'Afrique', '../../data/syc.svg', '../../data/syc.geo.json', 459, 'francais', 'https://fr.wikipedia.org/wiki/Seychelles', 'https://france-amerique.com/wp-content/uploads/2018/10/Screen-Shot-2018-10-11-at-10.28.33-AM-e1539277132933.png'),
(92, 'Tchad', 'Afrique', '../../data/tcd.svg', '../../data/tcd.geo.json', 1284000, 'francais', 'https://fr.wikipedia.org/wiki/Tchad', 'https://www.worldtravelguide.net/wp-content/uploads/2017/04/Think-Chad-590285132-konane-copy.jpg'),
(93, 'Togo', 'Afrique', '../../data/tgo.svg', '../../data/tgo.geo.json', 56785, ' francais', 'https://fr.wikipedia.org/wiki/Togo', 'https://www.togofirst.com/media/k2/items/cache/3dc2544c934ef7d30f24944cf2b0f793_L.jpg'),
(94, 'Tunisie', 'Afrique', '../../data/tun.svg', '../../data/tun.geo.json', 163610, 'Arabe', 'https://fr.wikipedia.org/wiki/Tunisie', 'https://www.tunisienumerique.com/wp-content/uploads/2020/06/tunisie.jpg'),
(95, 'Tanzanie', 'Afrique', '../../data/tza.svg', '../../data/tza.geo.json', 945087, 'swahili', 'https://fr.wikipedia.org/wiki/Tanzanie', 'https://www.partir.com/images/incontournables/tanzanie-zanzibar-ile.jpg'),
(96, 'Ouganda', 'Afrique', '../../data/uga.svg', '../../data/uga.geo.json', 241037, 'swahili', 'https://fr.wikipedia.org/wiki/Ouganda', 'https://www.challenges.tn/wp-content/uploads/2019/04/challenges-tn-Rwanda-Ethiopie-Ouganda-Tourisme.jpg'),
(97, 'Afrique du Sud', 'Afrique', '../../data/zaf.svg', '../../data/zaf.geo.json', 1220000, 'Zoulou', 'https://fr.wikipedia.org/wiki/Afrique_du_Sud', 'https://weekend.levif.be/medias/4160/2129955.jpg'),
(98, 'Zambie', 'Afrique', '../../data/zmb.svg', '../../data/zmb.geo.json', 752618, 'Anglais', 'https://fr.wikipedia.org/wiki/Zambie', 'https://www.laquotidienne.fr/wp-content/uploads/2019/03/course-1.jpg'),
(99, 'Zimbabwe', 'Afrique', '../../data/zwe.svg', '../../data/zwe.geo.json', 390757, 'shona', 'https://fr.wikipedia.org/wiki/Zimbabwe', 'https://www.eturbonews.com/wp-content/uploads/2018/08/ZW.jpg'),
(100, 'Benin', 'Afrique', '../../data/ben.svg', '../../data/ben.geo.json', 114763, 'francais', 'https://fr.wikipedia.org/wiki/B%C3%A9nin', 'https://cdn.thecrazytourist.com/wp-content/uploads/2016/03/Cotonou-Benin-1024x683.jpg'),
(101, 'Burkina Faso', 'Afrique', '../../data/bfa.svg', '../../data/bfa.geo.json', 274200, 'Francais', 'https://fr.wikipedia.org/wiki/Burkina_Faso', 'https://geo.img.pmdstatic.net/fit/http.3A.2F.2Fprd2-bone-image.2Es3-website-eu-west-1.2Eamazonaws.2Ecom.2Fgeo.2F2019.2F10.2F11.2F91a303bb-9e18-4611-9537-0d38fa52ae4f.2Ejpeg/980x552/background-color/ffffff/quality/90/picture.jpg'),
(102, 'Comores', 'Afrique', '../../data/com.svg', '../../data/com.geo.json', 1659, 'comorien', 'https://fr.wikipedia.org/wiki/Archipel_des_Comores', 'https://media-cdn.tripadvisor.com/media/photo-s/11/8c/04/1b/getlstd-property-photo.jpg'),
(103, 'Ethiopie', 'Afrique', '../../data/eth.svg', '../../data/eth.geo.json', 1104000, 'Amharique', 'https://fr.wikipedia.org/wiki/%C3%89thiopie', 'https://cdn.thecrazytourist.com/wp-content/uploads/2016/06/The-Blue-Nile-Falls.jpg'),
(104, 'Ghana', 'Afrique', '../../data/gha.svg', '../../data/gha.geo.json', 238535, 'Anglais', 'https://fr.wikipedia.org/wiki/Ghana', 'https://dynaimage.cdn.cnn.com/cnn/q_auto,w_412,c_fill,g_auto,h_232,ar_16:9/http%3A%2F%2Fcdn.cnn.com%2Fcnnnext%2Fdam%2Fassets%2F190206165057-senya-beraku.jpg'),
(105, 'Gambie', 'Afrique', '../../data/gmb.svg', '../../data/gmb.geo.json', 11295, 'Anglais', 'https://fr.wikipedia.org/wiki/Gambie', 'https://apanews.net/storage/app/uploads/public/5e6/d1a/df9/5e6d1adf9f76f555299452.jpg'),
(106, 'Angola', 'Afrique', '../../data/ago.svg', '../../data/ago.geo.json', 1247000, 'Portugais', 'https://fr.wikipedia.org/wiki/Angola', 'https://www.globaltourismforum.org/wp-content/uploads/2019/11/post-97.jpg'),
(107, 'Botswana', 'Afrique', '../../data/bwa.svg', '../../data/bwa.geo.json', 600370, 'Anglais', 'https://fr.wikipedia.org/wiki/Botswana', 'https://www.tourismprof.club/wp-content/uploads/botswana-tourism.jpg'),
(108, 'Republique centrafricaine', 'Afrique', '../../data/caf.svg', '../../data/caf.geo.json', 622984, 'sango', 'https://fr.wikipedia.org/wiki/R%C3%A9publique_centrafricaine', 'https://www.icrc.org/fr/doc/assets/images/photos/2013/car-01-ecosec-131219.jpg'),
(109, 'Burundi', 'Afrique', '../../data/bdi.svg', '../../data/bdi.geo.json', 27834, 'kirundi', 'https://fr.wikipedia.org/wiki/Burundi', 'https://afrotourism.com/wp-content/uploads/2015/03/SagaBeach1.jpg'),
(110, 'Cote dIvoire', 'Afrique', '../../data/civ.svg', '../../data/civ.geo.json', 322463, 'Francais', 'https://fr.wikipedia.org/wiki/C%C3%B4te_d%27Ivoire', 'https://www.brendansadventures.com/wp-content/uploads/2012/11/Yamoussoukro-Basilica-14.jpg'),
(111, 'Cameroun', 'Afrique', '../../data/cmr.svg', '../../data/cmr.geo.json', 475442, 'francais', 'https://fr.wikipedia.org/wiki/Cameroun', 'https://media.routard.com/image/71/1/cameroun-home-fiche.1472711.w740.jpg'),
(112, 'Republique democratique du Congo', 'Afrique', '../../data/cod.svg', '../../data/cod.geo.json', 2345000, 'Francais', 'https://fr.wikipedia.org/wiki/R%C3%A9publique_d%C3%A9mocratique_du_Congo', 'https://media.routard.com/image/38/9/congo-home-fiche.1473389.w740.jpg'),
(113, 'Republique du Congo', 'Afrique', '../../data/cog.svg', '../../data/cog.geo.json', 342000, 'Francais', 'https://fr.wikipedia.org/wiki/R%C3%A9publique_du_Congo', 'https://www.globalprotectioncluster.org/wp-content/uploads/JoBus-PCOM-2533-1170x780.jpg'),
(114, 'Cap vert', 'Afrique', '../../data/cpv.svg', '../../data/cpv.geo.json', 4033, 'Portugais', 'https://fr.wikipedia.org/wiki/Cap-Vert', 'https://www.portailsudmaroc.com/images/actualite/cap-vert-hotel.jpg'),
(115, 'Djibouti', 'Afrique', '../../data/dji.svg', '../../data/dji.geo.json', 23200, 'Francais', 'https://fr.wikipedia.org/wiki/Djibouti', 'https://sites.google.com/site/djiboutiembassyinjapan/_/rsrc/1322711199813/tourism-in-djibouti/009.jpg'),
(116, 'Algerie', 'Afrique', '../../data/dza.svg', '../../data/dza.geo.json', 2382000, 'Arabe', 'https://fr.wikipedia.org/wiki/Alg%C3%A9rie', 'https://pbs.twimg.com/media/EAa8aFkXkAAMGKi.jpg'),
(117, 'Egypte', 'Afrique', '../../data/egy.svg', '../../data/egy.geo.json', 1010000, 'Arabe', 'https://fr.wikipedia.org/wiki/%C3%89gypte', 'https://afrique.le360.ma/sites/default/files/styles/image_la_une_on_home_page/public/assets/images/2020/02/egypte_tourisme.jpg'),
(118, 'Erythree', 'Afrique', '../../data/eri.svg', '../../data/eri.geo.json', 117598, 'tigrigna', 'https://fr.wikipedia.org/wiki/%C3%89rythr%C3%A9e', 'https://img.lemde.fr/2010/12/15/232/0/3908/1954/688/0/60/0/ill_1454005_9fca_rtx5l48.jpg'),
(119, 'Sahara occidental', 'Afrique', '../../data/esh.svg', '../../data/esh.geo.json', 266000, 'Arabe', 'https://fr.wikipedia.org/wiki/Sahara_occidental', 'https://saharanews.org/wp-content/uploads/2020/06/laayoujne.jpg'),
(120, 'Gabon', 'Afrique', '../../data/gab.svg', '../../data/gab.geo.json', 267667, 'Francais', 'https://fr.wikipedia.org/wiki/Gabon', 'https://lp-cms-production.imgix.net/2019-06/184443531_high.jpg'),
(121, 'Guinee', 'Afrique', '../../data/gin.svg', '../../data/gin.geo.json', 245857, 'Francais', 'https://fr.wikipedia.org/wiki/Guin%C3%A9e', 'https://i.pinimg.com/originals/72/f9/9f/72f99ff2093a471ae076ca173ee3aa35.jpg'),
(122, 'Guinee Bissau', 'Afrique', '../../data/gnb.svg', '../../data/gnb.geo.json', 36125, 'Portugais', 'https://fr.wikipedia.org/wiki/Guin%C3%A9e-Bissau', 'https://static01.nyt.com/images/2009/11/08/travel/08Bijagosspan-1/articleLarge.jpg'),
(123, 'Guinee equatoriale', 'Afrique', '../../data/gnq.svg', '../../data/gnq.geo.json', 28050, 'espagnol', 'https://fr.wikipedia.org/wiki/Guin%C3%A9e_%C3%A9quatoriale', 'https://www.archiliste.fr/sites/default/files/styles/juicebox_medium/public/projets/enia-architectes/tour-guinee-guinee-equatoriale/2010997-4132-1.jpg'),
(124, 'Sri Lanka', 'Asie', '../../data/lka.svg', '../../data/lka.geo.json', 65610, 'tamoul', 'https://fr.wikipedia.org/wiki/Sri_Lanka', 'https://www.thehindu.com/news/cities/mumbai/h8309w/article28130408.ece/ALTERNATES/LANDSCAPE_1200/25bmSri-Lanka'),
(125, 'Macao', 'Asie', '../../data/mac.svg', '../../data/mac.geo.json', 115.3, 'chinois', 'https://fr.wikipedia.org/wiki/Macao', 'https://img.traveltriangle.com/blog/wp-content/tr:w-700,h-400/uploads/2016/07/Venetian-Macau.jpg'),
(126, 'Maldives', 'Asie', '../../data/mdv.svg', '../../data/mdv.geo.json', 297.8, 'Maldivien', 'https://fr.wikipedia.org/wiki/Maldives', 'https://www.telegraph.co.uk/content/dam/Travel/leadAssets/25/24/maldives_2524920a.jpg'),
(127, 'Myanmar', 'Asie', '../../data/mmr.svg', '../../data/mmr.geo.json', 676575, 'Birman', 'https://fr.wikipedia.org/wiki/Birmanie', 'https://thethaiger.com/wp-content/uploads/2020/02/features-of-myanmar-highlight-tourism-in-the-summer.jpg'),
(128, 'Mongolie', 'Asie', '../../data/mng.svg', '../../data/mng.geo.json', 1564000, 'Mongol', 'https://fr.wikipedia.org/wiki/Mongolie', 'https://previews.123rf.com/images/saiko3p/saiko3p1710/saiko3p171000775/87145763-ulaanbaatar-mongolie-11-juillet-2016-c%C3%A9l%C3%A9bration-du-festival-traditionnel-de-naadam-sur-la-place-ching.jpg'),
(129, 'Malaisie', 'Asie', '../../data/mys.svg', '../../data/mys.geo.json', 329847, 'Malais', 'https://fr.wikipedia.org/wiki/Malaisie', 'https://img-4.linternaute.com/JbPWvFHq_SEyD6BTcOM9kvExgA4=/660x366/smart/81a43afcb87e4deeb79b8c9c3c03bff7/ccmcms-linternaute/11100349.jpg'),
(130, 'Nepal', 'Asie', '../../data/npl.svg', '../../data/npl.geo.json', 147516, 'Nepalais', 'https://fr.wikipedia.org/wiki/N%C3%A9pal', 'https://www.usnews.com/dims4/USNEWS/e5438b6/2147483647/thumbnail/640x420/quality/85/?url=http%3A%2F%2Fmedia.beam.usnews.com%2F61%2Fed%2F9a06227147b1abca054383e95117%2F160425-nepaltourism-stock.jpg'),
(131, 'Oman', 'Asie', '../../data/omn.svg', '../../data/omn.geo.json', 309501, 'Arabe', 'https://fr.wikipedia.org/wiki/Oman', 'https://media-cdn.tripadvisor.com/media/photo-s/06/76/8d/85/sultanate-of-oman-tourism.jpg'),
(132, 'Pakistan', 'Asie', '../../data/pak.svg', '../../data/pak.geo.json', 881913, 'ourdou', 'https://fr.wikipedia.org/wiki/Pakistan', 'https://dailytimes.com.pk/assets/uploads/2019/09/tourism-in-Pakistan2.jpg'),
(133, 'Philippines', 'Asie', '../../data/phl.svg', '../../data/phl.geo.json', 300000, 'philippin', 'https://fr.wikipedia.org/wiki/Philippines', 'https://pix10.agoda.net/geo/country/70/3_70_philippines_02.jpg'),
(134, 'Coree du Nord', 'Asie', '../../data/prk.svg', '../../data/prk.geo.json', 120538, 'Coreen', 'https://fr.wikipedia.org/wiki/Cor%C3%A9e_du_Nord', 'https://www.ouest-france.fr/leditiondusoir/data/5337/NextGenData/Image-384-512-1381869.jpg'),
(135, 'Territoire Palestinien', 'Asie', '../../data/pse.svg', '../../data/pse.geo.json', 6220, 'Arabe', 'https://fr.wikipedia.org/wiki/Palestine', 'https://media.routard.com/image/63/2/israel-jerusalem.1491632.w740.jpg'),
(136, 'Syrie', 'Asie', '../../data/syr.svg', '../../data/syr.geo.json', 185180, 'Arabe', 'https://fr.wikipedia.org/wiki/Syrie', 'https://www.francetvinfo.fr/image/75imbm0w0-51ca/580/326/14200137.jpg'),
(137, 'Thailande', 'Asie', '../../data/tha.svg', '../../data/tha.geo.json', 513120, 'Thai', 'https://fr.wikipedia.org/wiki/Tha%C3%AFlande', 'https://tourismexpress.com/photos/images/thailande.jpg'),
(138, 'Tajikistan', 'Asie', '../../data/tjk.svg', '../../data/tjk.geo.json', 143100, 'Tadjik', 'https://fr.wikipedia.org/wiki/Tadjikistan', 'https://itap-world.com/uploads/countries/0/456/288.jpg'),
(139, 'Turkmenistan', 'Asie', '../../data/tkm.svg', '../../data/tkm.geo.json', 491210, 'Turkmene', 'https://fr.wikipedia.org/wiki/Turkm%C3%A9nistan', 'https://www.adequatetravel.com/blog/wp-content/uploads/2020/02/Feature-Image-7-1.jpg'),
(140, 'Timor oriental', 'Asie', '../../data/tls.svg', '../../data/tls.geo.json', 15006, 'portugais', 'https://fr.wikipedia.org/wiki/Timor_oriental', 'https://www.petermcmullin.com.au/wp-content/uploads/2018/02/Timor-Leste-Landscape-LR.jpg'),
(141, 'Taiwan', 'Asie', '../../data/twn.svg', '../../data/twn.geo.json', 36193, 'Mandarin', 'https://fr.wikipedia.org/wiki/Ta%C3%AFwan', 'https://cdn.budgetyourtrip.com/images/photos/headerphotos/large/taiwan_taipei.jpg'),
(142, 'Ouzbekistan', 'Asie', '../../data/uzb.svg', '../../data/uzb.geo.json', 448978, 'Ouzbek', 'https://fr.wikipedia.org/wiki/Ouzb%C3%A9kistan', 'https://www.lesvadrouilleurs.net/wp-content/uploads/ngg_featured/header-ouzbekistan.jpg'),
(143, 'Vietnam', 'Asie', '../../data/vnm.svg', '../../data/vnm.geo.json', 331210, 'Vietnamien', 'https://fr.wikipedia.org/wiki/Vi%C3%AAt_Nam', 'https://news.cgtn.com/news/3d3d674d35637a4e34457a6333566d54/img/0e7d97dcb694407ca8dade82f5e3d2b3/0e7d97dcb694407ca8dade82f5e3d2b3.jpg'),
(144, 'Yemen', 'Asie', '../../data/yem.svg', '../../data/yem.geo.json', 527968, 'Arabe', 'https://fr.wikipedia.org/wiki/Y%C3%A9men', 'https://www.yemenpress.org/wp-content/uploads/2019/12/Thula-village-M.jpg'),
(145, 'Japon', 'Asie', '../../data/jpn.svg', '../../data/jpn.geo.json', 377915, 'japonais', 'https://fr.wikipedia.org/wiki/Japon', 'https://img.jakpost.net/c/2016/08/22/2016_08_22_10245_1471858219._large.jpg'),
(146, 'Qatar', 'Asie', '../../data/qat.svg', '../../data/qat.geo.json', 11571, 'Arabe', 'https://fr.wikipedia.org/wiki/Qatar', 'https://www.leblogdesarah.com/wp-content/uploads/2019/02/voyage-qatar.jpg'),
(147, 'Bangladesh', 'Asie', '../../data/bgd.svg', '../../data/bgd.geo.json', 147570, 'Bengali', 'https://fr.wikipedia.org/wiki/Bangladesh', 'https://i.pinimg.com/originals/0a/5a/5f/0a5a5f54603af5a1c02c8fe6b7a62290.jpg'),
(148, 'Bahrein', 'Asie', '../../data/bhr.svg', '../../data/bhr.geo.json', 765.3, 'Arabe', 'https://fr.wikipedia.org/wiki/Bahre%C3%AFn', 'https://www.classtourisme.com/photo/art/grande/14159960-20199355.jpg'),
(149, 'Hong Kong', 'Asie', '../../data/hkg.svg', '../../data/hkg.geo.json', 1106, 'cantonais', 'https://fr.wikipedia.org/wiki/Hong_Kong', 'https://img.jakpost.net/c/2018/02/27/2018_02_27_41334_1519698496._large.jpg'),
(150, 'Indonesie', 'Asie', '../../data/idn.svg', '../../data/idn.geo.json', 1905000, 'Indonesien', 'https://fr.wikipedia.org/wiki/Indon%C3%A9sie', 'https://imagelecourrier.vnanet.vn/uploaded/2020/3/3/140756481afp1.jpg'),
(151, 'Inde', 'Asie', '../../data/ind.svg', '../../data/ind.geo.json', 3287000, 'hindi', 'https://fr.wikipedia.org/wiki/Inde', 'https://faceafrique.com/wp-content/uploads/2019/05/117f0a66e2aa6dd0c5fe7a65a94b5f81_l-780x405.jpg'),
(152, 'Iran', 'Asie', '../../data/irn.svg', '../../data/irn.geo.json', 1648000, 'Persan', 'https://fr.wikipedia.org/wiki/Iran', 'https://media.mehrnews.com/d/2019/11/19/4/3298967.jpg'),
(153, 'Irak', 'Asie', '../../data/irq.svg', '../../data/irq.geo.json', 437072, 'Arabe', 'https://fr.wikipedia.org/wiki/Irak', 'https://img.aws.la-croix.com/2018/09/05/1300966413/enfants-rives-Habbaniya-85-kilometres-ouest-Bagdad-22-2018_0_728_471.jpg'),
(154, 'Jordanie', 'Asie', '../../data/jor.svg', '../../data/jor.geo.json', 89342, 'Arabe', 'https://fr.wikipedia.org/wiki/Jordanie', 'https://weekend.levif.be/medias/11631/5955127.jpg'),
(155, 'Afghanistan', 'Asie', '../../data/afg.svg', '../../data/afg.geo.json', 652237, 'Pachto', 'https://fr.wikipedia.org/wiki/Afghanistan', 'https://i2.wp.com/www.hisour.com/wp-content/uploads/2018/07/Tourism-in-Afghanistan.jpg'),
(156, 'Kazakhstan', 'Asie', '../../data/kaz.svg', '../../data/kaz.geo.json', 2725000, 'kazakh', 'https://fr.wikipedia.org/wiki/Kazakhstan', 'https://img.traveltriangle.com/blog/wp-content/tr:w-700,h-400/uploads/2018/01/acj-2301-kazakhstan-tourist-attractions-6.jpg'),
(157, 'Kirghizistan', 'Asie', '../../data/kgz.svg', '../../data/kgz.geo.json', 199900, 'kirghize', 'https://fr.wikipedia.org/wiki/Kirghizistan', 'https://www.vizeo.net/wp-content/uploads/2017/03/VOYAGER-KIRGHIZISTAN-FILLE.jpeg'),
(158, 'Cambodge', 'Asie', '../../data/khm.svg', '../../data/khm.geo.json', 181035, 'Khmer', 'https://fr.wikipedia.org/wiki/Cambodge', 'https://i.pinimg.com/474x/a8/15/97/a8159760f3f49b22d75768bf541f9d5f.jpg'),
(159, 'Coree du Sud', 'Asie', '../../data/kor.svg', '../../data/kor.geo.json', 100210, 'Coreen', 'https://fr.wikipedia.org/wiki/Cor%C3%A9e_du_Sud', 'https://www.coree-voyage.com/wp-content/uploads/2012/06/plage-coree-du-sud.jpg'),
(160, 'Koweit', 'Asie', '../../data/kwt.svg', '../../data/kwt.geo.json', 17818, 'Arabe', 'https://fr.wikipedia.org/wiki/Kowe%C3%AFt', 'https://www.stophomophobie.com/wp-content/uploads/2015/06/CIbV0ShWcAAYKWF.png'),
(161, 'Laos', 'Asie', '../../data/lao.svg', '../../data/lao.geo.json', 236800, 'Lao', 'https://fr.wikipedia.org/wiki/Laos', 'https://www.wendywutours.co.uk/blog/wp-content/uploads/2017/06/laos-730x410.jpg'),
(162, 'Liban', 'Asie', '../../data/lbn.svg', '../../data/lbn.geo.json', 10452, 'Arabe', 'https://fr.wikipedia.org/wiki/Liban', 'https://media-cdn.tripadvisor.com/media/photo-c/2560x500/14/10/2d/fa/beirut.jpg'),
(163, 'Emirats Arabes Unis', 'Asie', '../../data/are.svg', '../../data/are.geo.json', 83600, 'Arabe', 'https://fr.wikipedia.org/wiki/%C3%89mirats_arabes_unis', 'https://www.leparisien.fr/resizer/55E89RUvsr4k6Gotbtgcw7hcrsI=/932x582/arc-anglerfish-eu-central-1-prod-leparisien.s3.amazonaws.com/public/XGWOHNW5OWAFJEFGPUY54KNOSY.jpg'),
(164, 'Arabie Saoudite', 'Asie', '../../data/sau.svg', '../../data/sau.geo.json', 2150000, 'Arabe', 'https://fr.wikipedia.org/wiki/Arabie_saoudite', 'https://www.tourmag.com/photo/art/default/37682089-33189575.jpg'),
(165, 'Singapour', 'Asie', '../../data/sgp.svg', '../../data/sgp.geo.json', 721.5, 'malais', 'https://fr.wikipedia.org/wiki/Singapour', 'https://www.tourmag.com/photo/art/grande/10727711-17692844.jpg'),
(166, 'Brunei', 'Asie', '../../data/brn.svg', '../../data/brn.geo.json', 5765, 'Malais', 'https://fr.wikipedia.org/wiki/Brunei', 'https://www.tourismprof.club/wp-content/uploads/brunei-tourism.jpg'),
(167, 'Bhoutan', 'Asie', '../../data/btn.svg', '../../data/btn.geo.json', 38394, 'Dzongkha', 'https://fr.wikipedia.org/wiki/Bhoutan', 'https://blog.altiplano-voyage.com/wp-content/uploads/2017/02/IMG_8947.jpg'),
(168, 'Iles Cocos', 'Asie', '../../data/cck.svg', '../../data/cck.geo.json', 14, 'Anglais', 'https://fr.wikipedia.org/wiki/%C3%8Eles_Cocos', 'https://www.les-iles-paradisiaques.com/uploadles-iles-paradisiaques.com/moyenne/20190626131837.jpg'),
(169, 'Chine', 'Asie', '../../data/chn.svg', '../../data/chn.geo.json', 9597000, 'Mandarin standard', 'https://fr.wikipedia.org/wiki/Chine', 'https://www.tourmag.com/photo/art/grande/17134733-21667942.jpg'),
(170, 'Iles Christmas', 'Asie', '../../data/cxr.svg', '../../data/cxr.geo.json', 135, 'chinois', 'https://fr.wikipedia.org/wiki/%C3%8Ele_Christmas_(Australie)', 'https://www.australia.com/content/australia/fr_fr/trips-and-itineraries/perth-and-surrounds/14-incredible-days-on-christmas-and-cocos-keeling-islands/_jcr_content/hero/mobile.adapt.768.high.jpg'),
(171, 'Armenie', 'Asie', '../../data/arm.svg', '../../data/arm.geo.json', 29743, 'Armenien', 'https://fr.wikipedia.org/wiki/Arm%C3%A9nie', 'https://i0.wp.com/destination-armenie.fr/wp-content/uploads/2018/02/Armenie-monastere-de-Tatev-tourisme.jpg'),
(172, 'Vatican', 'Europe', '../../data/vat.svg', '../../data/vat.geo.json', 0.49, 'latin', 'https://fr.wikipedia.org/wiki/Vatican', 'https://www.pope2you.net/wp-content/uploads/2019/06/Tourism-1.jpg'),
(173, 'Grece', 'Europe', '../../data/grc.svg', '../../data/grc.geo.json', 131957, 'Grec', 'https://fr.wikipedia.org/wiki/Gr%C3%A8ce', 'https://www.tourmag.com/photo/art/default/7714819-11938539.jpg'),
(174, 'Macedoine', 'Europe', '../../data/mkd.svg', '../../data/mkd.geo.json', 25713, 'macedonien', 'https://fr.wikipedia.org/wiki/Mac%C3%A9doine_(r%C3%A9gion)', 'https://www.atalante.fr/upload_1000/albanie_skojpe_albania_tradition_ld.jpg'),
(175, 'Malte', 'Europe', '../../data/mlt.svg', '../../data/mlt.geo.json', 316, 'maltais', 'https://fr.wikipedia.org/wiki/Malte', 'https://www.photoway.com/images/malte/MLT02_N2_08-tourisme-malte.jpg'),
(176, 'Iles Aland', 'Europe', '../../data/ala.svg', '../../data/ala.geo.json', 1580, 'Suedois', 'https://fr.wikipedia.org/wiki/%C3%85land', 'https://d34ip4tojxno3w.cloudfront.net/app/uploads/%C3%85land-small-harbour.jpg'),
(177, 'Albanie', 'Europe', '../../data/alb.svg', '../../data/alb.geo.json', 28748, 'Albanais', 'https://fr.wikipedia.org/wiki/Albanie', 'https://legourmandvoyageur.com/wp-content/uploads/2016/10/IMG_2568-Albanie-le-gourmand-voyageur.jpg'),
(178, 'Andorre', 'Europe', '../../data/and.svg', '../../data/and.geo.json', 468, 'Catalan', 'https://fr.wikipedia.org/wiki/Andorre', 'https://www.turismeandorralavella.com/wp-content/uploads/2017/12/andorra_la_vella_nit_hivern_home.jpg'),
(179, 'Autriche', 'Europe', '../../data/aut.svg', '../../data/aut.geo.json', 83879, 'Allemand', 'https://fr.wikipedia.org/wiki/Autriche', 'https://www.voltzenlogel.net/autriche/karnten-worthersee/velden-woerthersee/pic40.jpg'),
(180, 'Azerbaidjan', 'Europe', '../../data/aze.svg', '../../data/aze.geo.json', 86600, 'Azeri', 'https://fr.wikipedia.org/wiki/Azerba%C3%AFdjan', 'https://i.ytimg.com/vi/AyyM_Yxlmx4/maxresdefault.jpg'),
(181, 'Belgique', 'Europe', '../../data/bel.svg', '../../data/bel.geo.json', 30689, 'neerlandais', 'https://fr.wikipedia.org/wiki/Belgique', 'https://www.planetware.com/photos-large/B/belgium-brussels-la-grand-place-summer-day.jpg'),
(182, 'Bosnie Herzegovine', 'Europe', '../../data/bih.svg', '../../data/bih.geo.json', 51197, ' croate', 'https://fr.wikipedia.org/wiki/Bosnie-Herz%C3%A9govine', 'https://media-cdn.tripadvisor.com/media/photo-s/0e/51/68/e9/apparition-hill-medjugorje.jpg'),
(183, 'Bielorussie', 'Europe', '../../data/blr.svg', '../../data/blr.geo.json', 207595, 'bielorusse', 'https://fr.wikipedia.org/wiki/Bi%C3%A9lorussie', 'https://images.pouchkine-tours.com/(Image)-image-Belarus-Minsk-Panorama-14-fo_92466040-09032017.jpg'),
(184, 'Republique Tcheque', 'Europe', '../../data/cze.svg', '../../data/cze.geo.json', 78866, 'Tcheque', 'https://fr.wikipedia.org/wiki/Tch%C3%A9quie', 'https://prague-secrete.fr/wp-content/uploads/2019/11/prague-1845560_1920-1024x683.jpg'),
(185, 'France', 'Europe', '../../data/fra.svg', '../../data/fra.geo.json', 643801, 'Francais', 'https://fr.wikipedia.org/wiki/France', 'https://condorlivemedia.azureedge.net/cache/a/3/3/d/9/8/a33d98c68f469c8f11489523b7489cb4117c378b.jpg'),
(186, 'Iles Feroe', 'Europe', '../../data/fro.svg', '../../data/fro.geo.json', 1399, 'feroien', 'https://fr.wikipedia.org/wiki/%C3%8Eles_F%C3%A9ro%C3%A9', 'https://www.gngl.com/Content/img/Produits/produit/FRO/361321.ori.jpg'),
(187, 'Royaume Uni', 'Europe', '../../data/gbr.svg', '../../data/gbr.geo.json', 242495, 'Anglais', 'https://fr.wikipedia.org/wiki/Royaume-Uni', 'https://www.courrierinternational.com/sites/ci_master/files/styles/image_original_1280/public/assets/images/071_492-3610.jpg'),
(188, 'Hongrie', 'Europe', '../../data/hun.svg', '../../data/hun.geo.json', 93030, 'Hongrois', 'https://fr.wikipedia.org/wiki/Hongrie', 'https://media.routard.com/image/78/6/bokod-lake.1479786.w740.jpg'),
(189, 'Ile de Man', 'Europe', '../../data/imn.svg', '../../data/imn.geo.json', 572, 'mannois', 'https://fr.wikipedia.org/wiki/%C3%8Ele_de_Man', 'https://thumbs.dreamstime.com/b/au-sud-de-l-%C3%AEle-de-man-avec-la-tour-de-milner-38609338.jpg'),
(190, 'Irlande', 'Europe', '../../data/irl.svg', '../../data/irl.geo.json', 70273, 'irlandais', 'https://fr.wikipedia.org/wiki/Irlande', 'https://www.guide-irlande.com/wp-content/uploads/2013/11/fanad-head-lighthouse-1-scaled-1024x500.jpg'),
(191, 'Islande', 'Europe', '../../data/isl.svg', '../../data/isl.geo.json', 103000, 'Islandais', 'https://fr.wikipedia.org/wiki/Islande', 'https://img.lemde.fr/2017/05/31/0/0/2992/1994/688/0/60/0/845b7d4_6074-n7rwjo.9z7ngynwmi.jpg'),
(192, 'Italie', 'Europe', '../../data/ita.svg', '../../data/ita.geo.json', 301338, 'Italien', 'https://fr.wikipedia.org/wiki/Italie', 'https://img-4.linternaute.com/bxhsmMWJS-0Q1XmBNdEslE4NtfQ=/1080x/smart/e950aaa0ec2b487ab3b3482aeb013503/ccmcms-linternaute/11084411.jpg'),
(193, 'Jersey', 'Europe', '../../data/jey.svg', '../../data/jey.geo.json', 119.5, 'francais', 'https://fr.wikipedia.org/wiki/Jersey', 'https://www.lindigo-mag.com/photo/art/default/6353901-9587188.jpg'),
(194, 'Liechtenstein', 'Europe', '../../data/lie.svg', '../../data/lie.geo.json', 160, 'Allemand', 'https://fr.wikipedia.org/wiki/Liechtenstein', 'https://www.wanderingredhead.com/wp-content/uploads/2017/08/Vaduz-Castle.jpg'),
(195, 'Lituanie', 'Europe', '../../data/ltu.svg', '../../data/ltu.geo.json', 65300, 'Lituanie', 'https://fr.wikipedia.org/wiki/Lituanie', 'https://www.lithuania.travel/media/cache/2380x1340/uploads/mediaparkcms/slider/74693299cae55810d7ed06fa971d12ef5441e039.jpeg'),
(196, 'Luxembourg', 'Europe', '../../data/lux.svg', '../../data/lux.geo.json', 2586, 'luxembourgeois', 'https://fr.wikipedia.org/wiki/Luxembourg', 'https://1.bp.blogspot.com/-oaXKgYDyVds/XZAOXeLw9_I/AAAAAAABYbE/E2dxNXoM2QAzCWpJIV4_Vm3_55vLJ8RowCKgBGAsYHg/w1200-h630-p-k-no-nu/Luxembourg%2BCard5.jpg'),
(197, 'Lettonie', 'Europe', '../../data/lva.svg', '../../data/lva.geo.json', 64589, 'Letton', 'https://fr.wikipedia.org/wiki/Lettonie', 'https://live.staticflickr.com/2930/14718031452_2d198d1711_b.jpg'),
(198, 'Moldavie', 'Europe', '../../data/mda.svg', '../../data/mda.geo.json', 33846, 'Roumain', 'https://fr.wikipedia.org/wiki/Moldavie', 'https://images.pouchkine-tours.com/(vignette)-Vignette-Ukraine-Kiev-Petchersk-23-fo_97023651-09032017.jpg'),
(199, 'Montenegro', 'Europe', '../../data/mne.svg', '../../data/mne.geo.json', 13812, 'Montenegrin', 'https://fr.wikipedia.org/wiki/Mont%C3%A9n%C3%A9gro', 'https://cdn.cnn.com/cnnnext/dam/assets/170627120740-hiking-lovcen-kotor-photo-outdoor-mn-coastline-full-169.jpg'),
(200, 'Pays Bas', 'Europe', '../../data/nld.svg', '../../data/nld.geo.json', 41543, 'Neerlandais', 'https://fr.wikipedia.org/wiki/Pays-Bas', 'https://lvdneng.rosselcdn.net/sites/default/files/dpistyles_v2/ena_16_9_extra_big/2018/09/21/node_453844/39745614/public/2018/09/21/B9716984116Z.1_20180921161049_000%2BG94C2JNLN.3-0.jpg'),
(201, 'Norvege', 'Europe', '../../data/nor.svg', '../../data/nor.geo.json', 385203, 'Norvegien', 'https://fr.wikipedia.org/wiki/Norv%C3%A8ge', 'https://assets.simpleviewcms.com/simpleview/image/upload/c_fill,h_406,q_65,w_587/v1/clients/norway/Barcode-Oslo-Norway-2-1_bd5d9b33-a6cf-4db3-b77d-ff8ca69f8edf.jpg'),
(202, 'Pologne', 'Europe', '../../data/pol.svg', '../../data/pol.geo.json', 312679, 'Polonais', 'https://fr.wikipedia.org/wiki/Pologne', 'https://media.routard.com/image/71/2/gdansk.1486712.w740.jpg'),
(203, 'Portugal', 'Europe', '../../data/prt.svg', '../../data/prt.geo.json', 92212, 'Portugais', 'https://fr.wikipedia.org/wiki/Portugal', 'https://jingtravel.com/wp-content/uploads/2019/08/shutterstock_1449676064.jpg'),
(204, 'Russie', 'Europe', '../../data/rus.svg', '../../data/rus.geo.json', 17100000, 'Russe', 'https://fr.wikipedia.org/wiki/Russie', 'https://www.guderzo.eu/site/images/normal/moscow27426421920jpg_5beef13e6845d.jpg'),
(205, 'Georgie du Sud et les Iles Sandwich du Sud', 'Europe', '../../data/sgs.svg', '../../data/sgs.geo.json', 3903, 'anglais', 'https://fr.wikipedia.org/wiki/G%C3%A9orgie_du_Sud-et-les_%C3%AEles_Sandwich_du_Sud', 'https://planificateur.a-contresens.net/inspiration/2x1/gs.jpg'),
(206, 'Svalbard et Jan Mayen', 'Europe', '../../data/sjm.svg', '../../data/sjm.geo.json', 11, 'Norvegien', 'https://fr.wikipedia.org/wiki/Svalbard_et_Jan_Mayen', 'https://cdn.tourradar.com/s3/tour/1500x800/156931_07c75916.jpg'),
(207, 'San Marin', 'Europe', '../../data/smr.svg', '../../data/smr.geo.json', 61.2, 'Italien', 'https://fr.wikipedia.org/wiki/Saint-Marin', 'https://www.planetware.com/wpimages/2018/09/italy-san-marino-attractions-guaita-fortress.jpg'),
(208, 'Serbie', 'Europe', '../../data/srb.svg', '../../data/srb.geo.json', 88361, 'Serbe', 'https://fr.wikipedia.org/wiki/Serbie', 'https://cdn.thecrazytourist.com/wp-content/uploads/2016/03/Belgrade-Serbia.jpg'),
(209, 'Slovaquie', 'Europe', '../../data/svk.svg', '../../data/svk.geo.json', 49035, 'Slovaque', 'https://fr.wikipedia.org/wiki/Slovaquie', 'https://voyages.ideoz.fr/wp-content/uploads/2015/06/bratislava-centre-historique-880x536.jpg'),
(210, 'Slovenie', 'Europe', '../../data/svn.svg', '../../data/svn.geo.json', 20271, 'Slovene', 'https://fr.wikipedia.org/wiki/Slov%C3%A9nie', 'https://i.f1g.fr/media/figaro/704x396_crop/2015/03/27/XVMa0c74050-ccc7-11e4-a597-b0017117bef5-805x453.jpg'),
(211, 'Suede', 'Europe', '../../data/swe.svg', '../../data/swe.geo.json', 450295, 'Suedois', 'https://fr.wikipedia.org/wiki/Su%C3%A8de', 'https://www.tourismesuede.fr/wp-content/uploads/2018/01/smogen-suede-tourisme.jpg'),
(212, 'Turquie', 'Europe', '../../data/tur.svg', '../../data/tur.geo.json', 783562, 'Turc', 'https://fr.wikipedia.org/wiki/Turquie', 'https://www.novacorpus.fr/wp-content/uploads/2012/12/Medical-Tourism-Novacorpus-Turkey-e1357839259742.jpg'),
(213, 'Ukraine', 'Europe', '../../data/ukr.svg', '../../data/ukr.geo.json', 603628, 'Ukrainien', 'https://fr.wikipedia.org/wiki/Ukraine', 'https://img.112.international/original/2016/05/27/233421.jpg'),
(214, 'Bulgarie', 'Europe', '../../data/bgr.svg', '../../data/bgr.geo.json', 110994, 'Bulgare', 'https://fr.wikipedia.org/wiki/Bulgarie', 'https://www.blb-tourisme.bzh/wp-content/uploads/2017/04/Voyage-Bulgarie-Varna-mer-noire.jpg'),
(215, 'Suisse', 'Europe', '../../data/che.svg', '../../data/che.geo.json', 41285, 'Allemand', 'https://fr.wikipedia.org/wiki/Suisse', 'https://i.pinimg.com/originals/d5/5b/ee/d55beea6e9a0f4e9deb24ba17356704c.jpg'),
(216, 'Chypre', 'Europe', '../../data/cyp.svg', '../../data/cyp.geo.json', 9251, 'turc', 'https://fr.wikipedia.org/wiki/Chypre', 'https://pagtour.info/wp-content/uploads/2019/01/17-330-02_Zypern-e1544769394913-696x385-696x385.jpg'),
(217, 'Allemagne', 'Europe', '../../data/deu.svg', '../../data/deu.geo.json', 357386, 'Allemand', 'https://fr.wikipedia.org/wiki/Allemagne', 'https://i.pinimg.com/originals/75/c5/e4/75c5e4652446d22739490db5b03a5248.jpg');
INSERT INTO `mespays` (`id_pays`, `Nom_pays`, `Nom_continent`, `Flag`, `Reference`, `Surface`, `Langue`, `Lien`, `Img`) VALUES
(218, 'Danemark', 'Europe', '../../data/dnk.svg', '../../data/dnk.geo.json', 42933, 'Danois', 'https://fr.wikipedia.org/wiki/Danemark', 'https://www.trace-ta-route.com/wp-content/uploads/2017/09/Danemark-Copenhague-Nyhavn-1-L_Oeil_d_Edouard-690x460.jpg'),
(219, 'Espagne', 'Europe', '../../data/esp.svg', '../../data/esp.geo.json', 505990, 'Espagnol', 'https://fr.wikipedia.org/wiki/Espagne', 'https://chinesetouristagency.com/wp-content/uploads/2014/07/4217.jpg'),
(220, 'Roumanie', 'Europe', '../../data/rou.svg', '../../data/rou.geo.json', 238397, 'Roumain', 'https://fr.wikipedia.org/wiki/Roumanie', 'https://lepetitjournal.com/sites/default/files/styles/main_article/public/2019-07/hut-1681485_640.jpg'),
(221, 'Estonie', 'Europe', '../../data/est.svg', '../../data/est.geo.json', 45226, 'Estonien', 'https://fr.wikipedia.org/wiki/Estonie', 'https://a-autrement.ca/wp-content/uploads/2019/01/Estonie.jpeg'),
(222, 'Finlande', 'Europe', '../../data/fin.svg', '../../data/fin.geo.json', 338440, 'finnois', 'https://fr.wikipedia.org/wiki/Finlande', 'https://www.opodo.fr/blog/wp-content/uploads/sites/16/2016/11/cathedrale-d-helsinki-opodo.jpg'),
(223, 'Gribraltar', 'Europe', '../../data/gib.svg', '../../data/gib.geo.json', 6.8, 'Anglais', 'https://fr.wikipedia.org/wiki/Gibraltar', 'https://i.le360.ma/fr/sites/default/files/styles/asset_image_in_body/public/assets/images/2016/11/catalan_bay_village_beach.jpg'),
(224, 'Monaco', 'Europe', '../../data/mco.svg', '../../data/mco.geo.json', 2, 'Francais', 'https://fr.wikipedia.org/wiki/Monaco', 'https://english.cdn.zeenews.com/sites/default/files/2016/10/22/540472-monaco-ani.jpg'),
(225, 'Vanuatu', 'Oceanie', '../../data/vut.svg', '../../data/vut.geo.json', 12199, 'francais', 'https://fr.wikipedia.org/wiki/Vanuatu', 'https://devpolicy.org/wp-content/uploads/2015/06/aerial-28626.jpg'),
(226, 'Wallis et Futuna', 'Oceanie', '../../data/wlf.svg', '../../data/wlf.geo.json', 142.4, 'Francais', 'https://fr.wikipedia.org/wiki/Wallis-et-Futuna', 'https://www.wallis-et-futuna.wf/images/sampledata/voyager/voyager19.jpg'),
(227, 'Samoa', 'Oceanie', '../../data/wsm.svg', '../../data/wsm.geo.json', 2842, 'samoan', 'https://fr.wikipedia.org/wiki/Samoa', 'https://i.pinimg.com/originals/11/fc/e4/11fce45cd8f9e55b908c9188a3d45c72.jpg'),
(228, 'Polynesie francaise', 'Oceanie', '../../data/pyf.svg', '../../data/pyf.geo.json', 4167, 'Francais', 'https://fr.wikipedia.org/wiki/Polyn%C3%A9sie_fran%C3%A7aise', 'https://www.bestjobersblog.com/wp-content/uploads/2018/02/25-Polynesie-Rangiroa.jpg'),
(229, 'Australie', 'Oceanie', '../../data/aus.svg', '../../data/aus.geo.json', 7692000, 'anglais', 'https://fr.wikipedia.org/wiki/Australie', 'https://www.australia-australie.com/wp-content/uploads/2017/02/83-tourisme-australie.jpg'),
(230, 'Tonga', 'Oceanie', '../../data/ton.svg', '../../data/ton.geo.json', 747, 'tongien', 'https://fr.wikipedia.org/wiki/Tonga', 'https://i.pinimg.com/originals/8b/18/c5/8b18c5d2f1447ad3a16df734f5f43da5.jpg'),
(231, 'Kiribati', 'Oceanie', '../../data/kir.svg', '../../data/kir.geo.json', 811, 'gilbertin', 'https://fr.wikipedia.org/wiki/Kiribati', 'https://www.kiribatitourism.gov.ki/wp-content/uploads/2017/09/kiribati-beach.jpg'),
(232, 'Iles Marshall', 'Oceanie', '../../data/mhl.svg', '../../data/mhl.geo.json', 181.3, 'marshallais', 'https://fr.wikipedia.org/wiki/%C3%8Eles_Marshall', 'https://www.barouding.fr/blog/1440/les-iles-les-plus-retirees-de-la-planete-1505204324.jpg'),
(233, 'Iles Mariannes du Nord', 'Oceanie', '../../data/mnp.svg', '../../data/mnp.geo.json', 477, 'anglais', 'https://fr.wikipedia.org/wiki/%C3%8Eles_Mariannes_du_Nord', 'https://q-cf.bstatic.com/images/hotel/max1024x768/230/230181664.jpg'),
(234, 'Nouvelle Caledonie', 'Oceanie', '../../data/ncl.svg', '../../data/ncl.geo.json', 18575, 'Francais', 'https://fr.wikipedia.org/wiki/Nouvelle-Cal%C3%A9donie', 'https://media-cdn.tripadvisor.com/media/photo-s/12/47/13/b8/plage-et-ilot-en-nouvelle.jpg'),
(235, 'Ile Norfolk', 'Oceanie', '../../data/nfk.svg', '../../data/nfk.geo.json', 34.6, 'anglais', 'https://fr.wikipedia.org/wiki/%C3%8Ele_Norfolk', 'https://www.australia.com/content/australia/fr_fr/places/sydney-and-surrounds/guide-to-norfolk-island/_jcr_content/hero/mobile.adapt.768.high.jpg'),
(236, 'Niue', 'Oceanie', '../../data/niu.svg', '../../data/niu.geo.json', 261.5, 'niueen', 'https://fr.wikipedia.org/wiki/Niue', 'https://pacifique-a-la-carte.com/galerie/niue_images_34_1249532794_david_kirkland.jpg'),
(237, 'Nauru', 'Oceanie', '../../data/nru.svg', '../../data/nru.geo.json', 20.98, 'nauruan', 'https://fr.wikipedia.org/wiki/Nauru', 'https://looppacificassets.s3.amazonaws.com/styles/no_watermark/s3/thumbnails/image/tahiti_0.jpg?itok=28DGs3Hx'),
(238, 'Nouvelle Zelande', 'Oceanie', '../../data/nzl.svg', '../../data/nzl.geo.json', 268021, 'maori de nouvelle zelande', 'https://fr.wikipedia.org/wiki/Nouvelle-Z%C3%A9lande', 'https://tourisminfo.com.tn/wp-content/uploads/2018/11/Nouvelle-Zelande-780x405.jpg'),
(239, 'Iles Pitcairn', 'Oceanie', '../../data/pcn.svg', '../../data/pcn.geo.json', 47, 'pitcairnais', 'https://fr.wikipedia.org/wiki/%C3%8Eles_Pitcairn', 'https://media-cdn.tripadvisor.com/media/photo-s/19/19/6c/cf/non-vi-e-luogo-piu-remoto.jpg'),
(240, 'Palaos', 'Oceanie', '../../data/plw.svg', '../../data/plw.geo.json', 458, 'paluan', 'https://fr.wikipedia.org/wiki/Palaos', 'https://media-cdn.tripadvisor.com/media/photo-s/0f/14/a4/01/palau-aquarium.jpg'),
(241, 'Papouasie-Nouvelle-Guinee', 'Oceanie', '../../data/png.svg', '../../data/png.geo.json', 462840, 'tok pisin', 'https://fr.wikipedia.org/wiki/Papouasie-Nouvelle-Guin%C3%A9e', 'https://www.costacroisieres.fr/content/dam/costa/inventory-assets/countries/PNG/PNG.jpg.image.750.563.low.jpg'),
(242, 'Iles Salomon', 'Oceanie', '../../data/slb.svg', '../../data/slb.geo.json', 28399, 'Anglais', 'https://fr.wikipedia.org/wiki/%C3%8Eles_Salomon', 'https://i.pinimg.com/originals/1c/df/b2/1cdfb29bfa16057d70fa63f774bd0914.jpg'),
(243, 'Tokelau', 'Oceanie', '../../data/tkl.svg', '../../data/tkl.geo.json', 10, 'tokelau', 'https://fr.wikipedia.org/wiki/Tokelau', 'https://i.ytimg.com/vi/4YsCkpmKhPk/hqdefault.jpg'),
(244, 'Tuvalu', 'Oceanie', '../../data/tuv.svg', '../../data/tuv.geo.json', 25.9, 'tuvaluan', 'https://fr.wikipedia.org/wiki/Tuvalu', 'https://s3.amazonaws.com/new-wordpress/timelesstuvalu/wp-content/uploads/2019/06/SPTO_TUV_019_DK_2013.jpg'),
(245, 'Iles Cook', 'Oceanie', '../../data/cok.svg', '../../data/cok.geo.json', 236.7, 'maori des iles cook', 'https://fr.wikipedia.org/wiki/%C3%8Eles_Cook', 'https://media-cdn.tripadvisor.com/media/photo-s/07/8b/8b/ed/photo-provided-by-cook.jpg'),
(246, 'Fidji', 'Oceanie', '../../data/fji.svg', '../../data/fji.geo.json', 18333, 'fidjien', 'https://fr.wikipedia.org/wiki/Fidji', 'https://media.routard.com/image/71/7/fidji-home-fiche.1472717.w740.jpg'),
(247, 'Micronesie', 'Oceanie', '../../data/fsm.svg', '../../data/fsm.geo.json', 702, 'Anglais', 'https://fr.wikipedia.org/wiki/Micron%C3%A9sie_(r%C3%A9gion)', 'https://www.gayvoyageur.com/wp-content/uploads/2019/01/destination-gay-micronesie.jpg'),
(248, 'Antarctique', '', 'data/ata.svg', 'data/ata.geo.json', 14000000, 'francais', 'https://fr.wikipedia.org/wiki/Antarctique', 'https://tourismeautrement.files.wordpress.com/2010/04/ours-polaire.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `parties`
--

CREATE TABLE `parties` (
  `id` int(11) NOT NULL,
  `score_max` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `parties`
--

INSERT INTO `parties` (`id`, `score_max`) VALUES
(33, 1000),
(34, 800),
(35, 1500);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `membres`
--
ALTER TABLE `membres`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mail` (`mail`);

--
-- Index pour la table `mespays`
--
ALTER TABLE `mespays`
  ADD PRIMARY KEY (`id_pays`);

--
-- Index pour la table `parties`
--
ALTER TABLE `parties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_joueur` (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `membres`
--
ALTER TABLE `membres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT pour la table `mespays`
--
ALTER TABLE `mespays`
  MODIFY `id_pays` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=249;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `parties`
--
ALTER TABLE `parties`
  ADD CONSTRAINT `parties_ibfk_1` FOREIGN KEY (`id`) REFERENCES `membres` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
